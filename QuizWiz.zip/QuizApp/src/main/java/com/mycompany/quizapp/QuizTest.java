package com.mycompany.quizapp;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ExecutionException;

public class QuizTest extends JFrame implements ActionListener {
    JLabel label, timerLabel;
    JRadioButton radioButtons[] = new JRadioButton[4]; // Only 4 options are needed per question
    JButton btnNext, btnResult;
    ButtonGroup bg;
    int count = 0, current = 0;
    int timeLimit = 10; // Time limit for each question in seconds
    Thread timerThread;

    QuizTest(String s) {
        super(s);
        label = new JLabel();
        timerLabel = new JLabel("Time left: " + timeLimit + " seconds");
        add(label);
        add(timerLabel);
        bg = new ButtonGroup();
        for (int i = 0; i < 4; i++) { // 4 radio buttons for 4 options per question
            radioButtons[i] = new JRadioButton();
            add(radioButtons[i]);
            bg.add(radioButtons[i]);
        }

        btnNext = new JButton("Next");
        btnResult = new JButton("Result");
        btnResult.setVisible(false); // Result button is hidden until the last question
        btnNext.addActionListener(this);
        btnResult.addActionListener(this);
        add(btnNext);
        add(btnResult);

        // Positioning
        label.setBounds(30, 40, 450, 20);
        timerLabel.setBounds(450, 40, 150, 20); // Position the timer label
        radioButtons[0].setBounds(50, 80, 200, 20);
        radioButtons[1].setBounds(50, 110, 200, 20);
        radioButtons[2].setBounds(50, 140, 200, 20);
        radioButtons[3].setBounds(50, 170, 200, 20);
        btnNext.setBounds(100, 240, 100, 30);
        btnResult.setBounds(270, 240, 100, 30);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocation(250, 100);
        setVisible(true);
        setSize(600, 350);

        loadQuestion(); // Load the first question and start the timer thread
    }

    void loadQuestion() {
        // Start the thread timer for each question
        startTimer();

        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                // Simulate delay for loading the question (e.g., fetching from server)
                Thread.sleep(1000); // 1-second delay (optional, simulating fetching)
                return null;
            }

            @Override
            protected void done() {
                try {
                    get(); // To handle any exceptions that occurred in doInBackground
                    setData(); // Once the delay is done, load the question
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
        };
        worker.execute(); // Start the background thread
    }

    void setData() {
        bg.clearSelection(); // Clear previous selection
        if (current == 0) {
            label.setText("Q1: Which is the official language for Android development?");
            radioButtons[0].setText("Java");
            radioButtons[1].setText("Kotlin");
            radioButtons[2].setText("C++");
            radioButtons[3].setText("JavaScript");
        } else if (current == 1) {
            label.setText("Q2: What is 2 + 2?");
            radioButtons[0].setText("3");
            radioButtons[1].setText("4");
            radioButtons[2].setText("5");
            radioButtons[3].setText("0");
        } else if (current == 2) {
            label.setText("Q3: What is 2 * 8?");
            radioButtons[0].setText("16");
            radioButtons[1].setText("14");
            radioButtons[2].setText("10");
            radioButtons[3].setText("-2");
        } else if (current == 3) {
            label.setText("Q4: What is 4 - 9?");
            radioButtons[0].setText("5");
            radioButtons[1].setText("-5");
            radioButtons[2].setText("0");
            radioButtons[3].setText("1");
        } else if (current == 4) {
            label.setText("Q5: Which is the official language for Android development?");
            radioButtons[0].setText("Java");
            radioButtons[1].setText("Kotlin");
            radioButtons[2].setText("C++");
            radioButtons[3].setText("JavaScript");
        }
    }

    boolean checkAns() {
        if (current == 0) {
            return radioButtons[1].isSelected(); // Correct answer for Q1 is Kotlin
        } else if (current == 1) {
            return radioButtons[1].isSelected(); // Correct answer for Q2 is 4
        } else if (current == 2) {
            return radioButtons[0].isSelected(); // Correct answer for Q3 is 16
        } else if (current == 3) {
            return radioButtons[1].isSelected(); // Correct answer for Q4 is -5
        } else if (current == 4) {
            return radioButtons[1].isSelected(); // Correct answer for Q5 is Kotlin
        }
        return false;
    }

    void loadNextQuestion() {
        if (checkAns()) {
            count++; // Increase the count if the answer is correct
        }
        current++;
        if (current < 5) { // Ensure it doesn't exceed available questions
            loadQuestion(); // Load the next question
        } else {
            btnNext.setEnabled(false); // Disable the Next button after all questions
            btnResult.setVisible(true); // Show the result button
        }
    }

    void startTimer() {
        // Stop the previous timer thread if it's running
        if (timerThread != null && timerThread.isAlive()) {
            timerThread.interrupt();
        }

        // Start a new thread for the timer
        timerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Countdown for the time limit (10 seconds here)
                    for (int i = timeLimit; i > 0; i--) {
                        final int timeRemaining = i;
                        SwingUtilities.invokeLater(() -> timerLabel.setText("Time left: " + timeRemaining + " seconds"));
                        Thread.sleep(1000); // Sleep 1 second at a time
                    }
                    // Time's up, load the next question
                    SwingUtilities.invokeLater(() -> loadNextQuestion());
                } catch (InterruptedException e) {
                    // If the thread is interrupted (user submits answer early), stop
                    System.out.println("Timer interrupted.");
                }
            }
        });

        timerThread.start(); // Start the timer thread
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnNext) {
            // User clicked Next, interrupt the timer and load the next question
            if (timerThread != null && timerThread.isAlive()) {
                timerThread.interrupt();
            }
            loadNextQuestion();
        } else if (e.getSource() == btnResult) {
            if (checkAns()) {
                count++;
            }
            JOptionPane.showMessageDialog(this, "Correct Answers: " + count);
            System.exit(0); // Close the application after showing the result
        }
    }

    public static void main(String[] args) {
        new QuizTest("Simple Quiz App");
    }
}
