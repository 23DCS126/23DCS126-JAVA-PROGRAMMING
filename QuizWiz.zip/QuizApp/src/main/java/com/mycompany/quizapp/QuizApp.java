/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizapp;

/**
 *
 * @author nares
 */
public class QuizApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
